package shadersmod.common;

/* loaded from: ShadersMod-v2.7.1mc1.12.2-dev.jar:shadersmod/common/SMCVersion.class */
public class SMCVersion {
    public static final String mcVersion = "1.12.2";
    public static final String versionString = "2.7.1";
    public static final int versionNumber = 132865;
    public static final int buildNumber = 2;
}

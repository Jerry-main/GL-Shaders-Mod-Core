package shadersmod.common;

/* loaded from: ShadersMod-v2.7.1mc1.12-dev.jar:shadersmod/common/SMCEnvironment.class */
public class SMCEnvironment {
    public static boolean hasOptiFine = false;
    public static boolean hasForge = false;
}

package shadersmod.client;

/* loaded from: ShadersMod-v2.7.1mc1.12-dev.jar:shadersmod/client/SVertexAttrib.class */
public class SVertexAttrib {
    public int index;
    public int count;
    public a type;
    public int offset;

    public SVertexAttrib(int index, int count, a type) {
        this.index = index;
        this.count = count;
        this.type = type;
    }
}

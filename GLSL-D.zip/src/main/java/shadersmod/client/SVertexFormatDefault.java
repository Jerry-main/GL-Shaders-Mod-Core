package shadersmod.client;

/* loaded from: ShadersMod-v2.7.1mc1.12-dev.jar:shadersmod/client/SVertexFormatDefault.class */
public class SVertexFormatDefault {
}

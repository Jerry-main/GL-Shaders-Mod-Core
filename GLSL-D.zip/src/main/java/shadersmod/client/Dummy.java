package shadersmod.client;

import java.nio.FloatBuffer;
import java.nio.IntBuffer;
import java.util.List;
import java.util.Map;

/* loaded from: ShadersMod-v2.7.1mc1.12-dev.jar:shadersmod/client/Dummy.class */
public abstract class Dummy {
    public static SVertexBuffer get_vertexBuffer_sVertexBuffer(bui object) {
        return null;
    }

    public static void put_vertexBuffer_sVertexBuffer(bui object, SVertexBuffer value) {
    }

    public static int get_vertexFormat_tangentElementOffset(cdy object) {
        return 0;
    }

    public static void put_vertexFormat_tangentElementOffset(cdy object, int value) {
    }

    public static int get_vertexFormat_entityElementOffset(cdy object) {
        return 0;
    }

    public static void put_vertexFormat_entityElementOffset(cdy object, int value) {
    }

    public static int get_vertexFormat_miduvElementOffset(cdy object) {
        return 0;
    }

    public static void put_vertexFormat_miduvElementOffset(cdy object, int value) {
    }

    public static MultiTexID get_abstractTexture_multiTex(cdd object) {
        return null;
    }

    public static void put_abstractTexture_multiTex(cdd object, MultiTexID value) {
    }

    public static int get_textureMap_atlasWidth(cdn object) {
        return 0;
    }

    public static void put_textureMap_atlasWidth(cdn object, int value) {
    }

    public static int get_textureMap_atlasHeight(cdn object) {
        return 0;
    }

    public static void put_textureMap_atlasHeight(cdn object, int value) {
    }

    public static void invoke_modelRenderer_resetDisplayList(brq object) {
    }

    public static MultiTexID invoke_iTextureObject_getMultiTexID(cdq object) {
        return null;
    }

    public static int get_entityRenderer_frameCount(buo object) {
        return 0;
    }

    public static void put_entityRenderer_frameCount(buo object, int value) {
    }

    public static IntBuffer get_vertexBuffer_rawIntBuffer(bui object) {
        return null;
    }

    public static void put_vertexBuffer_rawIntBuffer(bui object, IntBuffer value) {
    }

    public static FloatBuffer get_vertexBuffer_rawFloatBuffer(bui object) {
        return null;
    }

    public static void put_vertexBuffer_rawFloatBuffer(bui object, FloatBuffer value) {
    }

    public static int get_vertexBuffer_vertexCount(bui object) {
        return 0;
    }

    public static void put_vertexBuffer_vertexCount(bui object, int value) {
    }

    public static int get_vertexBuffer_rawBufferIndex(bui object) {
        return 0;
    }

    public static void put_vertexBuffer_rawBufferIndex(bui object, int value) {
    }

    public static int get_vertexBuffer_drawMode(bui object) {
        return 0;
    }

    public static void put_vertexBuffer_drawMode(bui object, int value) {
    }

    public static cdz get_vertexBuffer_vertexElement(bui object) {
        return null;
    }

    public static void put_vertexBuffer_vertexElement(bui object, cdz value) {
    }

    public static int get_vertexBuffer_vertexElementIndex(bui object) {
        return 0;
    }

    public static void put_vertexBuffer_vertexElementIndex(bui object, int value) {
    }

    public static String get_textureMap_basePath(cdn object) {
        return null;
    }

    public static void put_textureMap_basePath(cdn object, String value) {
    }

    public static List<Integer> get_vertexFormat_offsets(cdy object) {
        return null;
    }

    public static void put_vertexFormat_offsets(cdy object, List value) {
    }

    public static int get_vertexFormat_nextOffset(cdy object) {
        return 0;
    }

    public static void put_vertexFormat_nextOffset(cdy object, int value) {
    }

    public static int get_vertexFormat_colorElementOffset(cdy object) {
        return 0;
    }

    public static void put_vertexFormat_colorElementOffset(cdy object, int value) {
    }

    public static List<Integer> get_vertexFormat_uvOffsets(cdy object) {
        return null;
    }

    public static void put_vertexFormat_uvOffsets(cdy object, List value) {
    }

    public static int get_vertexFormat_normalElementOffset(cdy object) {
        return 0;
    }

    public static void put_vertexFormat_normalElementOffset(cdy object, int value) {
    }

    public static Map get_renderManager_entityRenderMap(bzd object) {
        return null;
    }

    public static int get_abstractTexture_glTextureId(cdd object) {
        return 0;
    }

    public static void put_abstractTexture_glTextureId(cdd object, int value) {
    }

    public static boolean get_texturedQuad_invertNormal(bqj object) {
        return false;
    }

    public static void put_texturedQuad_invertNormal(bqj object, boolean value) {
    }

    public static void invoke_entityRenderer_renderHand(buo object, float par0, int par1) {
    }

    public static void invoke_entityRenderer_setupCameraTransform(buo entityRenderer, float partialTicks, int pass) {
    }

    public static nd invoke_textureMap_completeResLoc(cdn object, nd name, int level) {
        return null;
    }

    public static void invoke_forgeHooksClient_setRenderPass(int pass) {
    }
}
